﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CKK.Online.Models
{
    public class CheckOutModel
    {
        public string StatusMessage { get; set; }
    }
}
